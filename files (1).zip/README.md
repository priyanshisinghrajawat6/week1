# Data Science Internship: Next Gen Software Hub Pvt. Ltd.

## Week 1: Introduction to Data Science & Python Basics

This repository contains my Week 1 assignment and project report.

### Contents
| File | Description |
|------|-------------|
| `Week1_Assignment.ipynb` | Python basics: conditions, loops, functions, lists, dictionaries + mini project |
| `Week1_Project_Report.pdf` | Project report: dataset, approach, results |

### Topics Covered
- Variables and data types
- Conditions (`if / elif / else`)
- Loops (`for`, `while`)
- Functions
- Lists and dictionaries
- Mini project: Student Marks Analyzer

### How to Run
**Google Colab:** upload `Week1_Assignment.ipynb`, then Runtime -> Run all.
**Jupyter / Anaconda:** open the notebook and choose Cell -> Run All.

No external libraries are needed (Python 3 only).

### Tools
Python 3, Jupyter Notebook, Google Colab, Anaconda, Git

### Author
Your Name Here
